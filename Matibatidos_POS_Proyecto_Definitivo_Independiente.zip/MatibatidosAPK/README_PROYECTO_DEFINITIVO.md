# Matibatidos POS Definitiva — proyecto Android independiente

## Qué contiene
- Código Android nativo y WebView basado en el proyecto Android anterior de Matibatidos.
- Interfaz POS incorporada desde `index_matibatidos_pos_v55.html`, la versión fuente más reciente recuperada del historial de archivos disponible.
- Identificador Android independiente: `com.matibatidos.pos.definitiva`. No actualiza ni reemplaza `com.matibatidos.pos` (la instalación 1.0.5 actual).
- Versión de esta aplicación: `2.0.0-definitiva` (versionCode 1).
- Flujo de GitHub Actions para compilar el APK desde el proyecto directamente.
- Compatibilidad añadida para importar el respaldo externo con estructura `{app, version, createdAt, data:{state, users, activity, storage, images}}`, además de los formatos anteriores.

## Importante sobre los datos
La APK actual no se modifica. Instala esta aplicación como una app separada. Abre Matibatidos POS Definitiva, inicia sesión con las credenciales que correspondan al respaldo y restaura el JSON del 7 de noviembre desde Configuración / Datos. La restauración borra la sesión antigua y solicita iniciar sesión otra vez.

El importador reconoce `data.state`, `data.users`, `data.activity` y las claves `matibatidos_*` de `data.storage`. Si el paquete `data.images` supera el espacio disponible en almacenamiento local, el código conserva el estado principal y registra el problema en la consola; por ello debe verificarse la restauración de imágenes en el dispositivo antes de considerar migración terminada.

## Compilación
1. Sube el contenido de este ZIP a un repositorio nuevo de GitHub (rama `principal`).
2. Abre la pestaña Actions y ejecuta **Construir Matibatidos POS Definitiva**.
3. Descarga el artefacto `Matibatidos-POS-Definitiva-2.0.0`.

La compilación usa firma debug automática de GitHub Actions. Para futuras actualizaciones de ESTA app independiente, debe configurarse una clave de firma permanente y conservarse fuera del repositorio.

## Alcance y verificación
Este ZIP es el proyecto fuente; no es todavía una APK compilada ni una prueba de restauración en el dispositivo. La interfaz fuente recuperada es v55; los cambios que solo existan en archivos posteriores no recuperados no se pueden afirmar como incorporados. No desinstales la versión 1.0.5 ni elimines el respaldo original.
